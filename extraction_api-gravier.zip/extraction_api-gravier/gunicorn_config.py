# gunicorn_config.py

bind = "0.0.0.0:8080"
workers = 4
threads = 2
worker_class = "sync"